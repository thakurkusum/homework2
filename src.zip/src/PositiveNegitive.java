import java.util.Scanner;

public class PositiveNegitive {
    public static void main(String[] args) {
        Scanner obj =new Scanner(System.in);

        System.out.println("please enter a number");
        double number = obj.nextDouble();

        if (number < 0.0)
            System.out.println(number + " is a negative number.");
        else if (number > 0.0)
            System.out.println(number +" is a positive number");
        else
            System.out.println(number + "is 0");
    }
}
