import java.util.Scanner;



public class SalaryBonus {
    public static void main(String[] args) {
        int salescom=0;
        String comper="";
        Scanner id = new Scanner(System.in);
        Scanner name = new Scanner(System.in);
        Scanner amount = new Scanner(System.in);
        Scanner salary = new Scanner(System.in);

        System.out.println( "Please enter your ID");
        int salesid = id.nextInt();

        System.out.println("Please enter seller's name");
        String sellers = name.nextLine();

        System.out.println( "Please enter sales amount");
        int saleamt = amount.nextInt();

        System.out.println( "Please enter your salary");
        int basesal = salary.nextInt();

        System.out.println(salesid);
        System.out.println(sellers);
        System.out.println(saleamt);
        System.out.println(basesal);

        if (saleamt < 10000)
            salescom = basesal *2 / 100;

        else if (saleamt >=10000 && saleamt<=20000)
            salescom = basesal* 5/ 100;

        else if(saleamt >=20000 && saleamt<=30000)
          salescom = basesal* 10/ 100;
            System.out.println(salescom);
        }
    }