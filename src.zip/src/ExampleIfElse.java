public class ExampleIfElse{
    public static void main (String[]args){

        int a=10;
        int b=10;
        if(a>0 && b>0){
          System.out.println("A and b is positive");
        }
      else if (a>0 || b>0){
            System.out.println("A is positive");


        }
        else
            System.out.println("both is Negative");

    }



}



