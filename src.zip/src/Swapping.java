import java.util.Scanner;

public class Swapping {
    public static void main(String[] args) {

        int a, b, temp;
        System.out.println("enter a and b");

        Scanner in = new Scanner(System.in);
        a = in.nextInt();
        b = in.nextInt();

        System.out.println("before Swapping\na = "+a+" \nb =" +b);

        temp = a;
        a =b;
        b = temp;

        System.out.println("after Swapping\na = "+a+"\nb = "+b);

    }
}
