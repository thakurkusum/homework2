import java.util.Scanner;


  public class Scanner2 {
    public static void main(String[] args) {

        Scanner object = new Scanner(System.in);
        System.out.println( "Please enter your number");

        int marks = object.nextInt();

        Scanner object1 = new Scanner(System.in);
        System.out.println("Please enter your name");
        String name = object1.nextLine();

        if (marks >= 35 && marks < 50)
        {
            System.out.println(name);
            System.out.println("pass");
        }
        else if (marks >=50 && marks <60)
        {
            System.out.println("Second Class");
        }
        else if (marks >= 60 && marks <80){
            System.out.println("first class");

        }else if (marks >80){
            System.out.println("Distinction");

        }

        else{
            System.out.println("fail");
        }

    }
}

