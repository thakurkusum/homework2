public class SecondJava {

    public SecondJava (String name){
        System.out.println("passed name is: SecondJava");

    }

    public static void main(String[] args) {
        SecondJava java=new SecondJava("feeling great");
    }
}





