public class Example {
   // static int a = 10;
  //  static int b = 20;
    static int ans;
                                                  //no return with parameter
    public static void sub (int a,int b){
        ans = a - b;
        System.out.println(ans);

    }
     public static void main (String[]arg){
        sub ( 10, 20);
        sub ( 50, 40);
        sub ( 600, 5000);
     }




}
