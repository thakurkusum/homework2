public class math {
    public static void main(String[] args) {


        int a = 20;
        int b = 10;
        int add  = a + b;
        int sub=a-b;
        int multiply=a*b;
        float divide=a/b;
            System.out.println(add);
        System.out.println(sub);
        System.out.println(multiply);
        System.out.println(divide);

        }
    }










