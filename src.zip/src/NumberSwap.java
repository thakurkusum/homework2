public class NumberSwap{
    public static void main (String[]arg){

        float one =15.20f, two = 12.25f;
        System.out.println("--before swap--");
        System.out.println(" number one = " + one);
        System.out.println(" number two = "+ two);

        float temporary =one;

        one = two;

        two = temporary;

        System.out.println("--after swap--");
        System.out.println(" number one = "+ one);
        System.out.println(" number two = "+ two);

    }
}
