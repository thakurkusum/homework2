public class JavaSession {
}
