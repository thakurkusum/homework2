public class Example2 {
     int dog=1000;
     //Non static method with parameter

    public void addition (int a, int b){
      dog =a + b;
      System.out.println(dog);

    }
    public static void main (String[]args){
        Example2 x = new Example2();
        x.addition(10,20);
        x.addition(20,30);
    }
}
